#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<windows.h> 
typedef struct PolyNode {
    double coef;           
    int exp;               
	struct PolyNode* next; 
}PolyNode,*Polylist;

typedef struct allPoly{
	Polylist *polys;   
    int count;         
    int capacity; 
}PolyManager;
//���д洢������ 

//�����ǹ��ܺ��� 
int analysis(char*input,PolyNode terms[]);//��������
Polylist createPoly();//�����ն���ʽ 
Polylist createPolyfrominput();//���û�����������������ʽ 
void printfpoly(Polylist poly);//�������ʽ 
Polylist Ployadd(Polylist poly_a,Polylist poly_b);//����ʽ�ӷ� 
Polylist Ployminus(Polylist poly_a,Polylist poly_b);//����ʽ���� 
Polylist Polymulti(Polylist poly_a,Polylist poly_b);//����ʽ�˷� 
int compareExp(int a,int b);//ָ���Ƚ� 
void Deletepoly(Polylist poly);//����ʽɾ�� 
void display_menu();//�˵���ʾ 
void insertNode(Polylist poly, double coef, int exp);//�������

//�����ǲ˵��ĺ���
// ��ʼ������ʽ������
void initPolyManager();
//��������ʽ���� 
void expandPolyManager();
//��ö���ʽ���� 
char* getPolyName(int index);
//����ʽ��ʾ
void showAllPolys();
//ѡ�����ʽ
int selectPoly();
//���Ӷ���ʽ 
int addNewPoly(Polylist poly);


PolyManager polyManager = {NULL, 0, 0};


int main()
{
	initPolyManager();
	display_menu();
	return 0;
}

int addNewPoly(Polylist poly){
    if(polyManager.count>=polyManager.capacity){
        expandPolyManager();
    }
    
    polyManager.polys[polyManager.count]=poly;
    polyManager.count++;
    return polyManager.count-1; // �����¶���ʽ������
}

// ��ʼ������ʽ������
void initPolyManager(){
    polyManager.capacity=10;
    polyManager.polys=(Polylist*)malloc(polyManager.capacity*sizeof(Polylist));
    polyManager.count=0;
    
    // ��ʼ�������ն���ʽ
    polyManager.polys[0]=createPoly();
    polyManager.polys[1]=createPoly();
    polyManager.polys[2]=createPoly();
    polyManager.polys[3]=createPoly();
    polyManager.polys[4]=createPoly();
    polyManager.count=5;
}

//��������ʽ���� 
void expandPolyManager()
{
    int newCapacity=polyManager.capacity*2;
    Polylist*newPolys=(Polylist*)malloc(newCapacity*sizeof(Polylist));
    int i=0;
    for(i=0;i<polyManager.count; i++){
        newPolys[i]=polyManager.polys[i];
    }
    
    free(polyManager.polys);
    polyManager.polys=newPolys;
    polyManager.capacity=newCapacity;
}

//��ö���ʽ���� 
char* getPolyName(int index){
    static char name[20];
    sprintf(name,"����ʽ%d",index+1);
    return name;
}

//����ʽ��ʾ
void showAllPolys(){
    printf("\n��ǰ���ж���ʽ:\n");
    printf("====================\n");
    int i; 
    for(i=0;i<polyManager.count;i++)
		{
        	if(polyManager.polys[i]!=NULL&&polyManager.polys[i]->next != NULL)
			{
            	printf("%d.%s:",i+1,getPolyName(i));
            	printfpoly(polyManager.polys[i]);
        	}
			else{
        	    printf("%d. %s:��\n",i+1,getPolyName(i));
        	}
    }
    printf("====================\n");
}

// ѡ�����ʽ
int selectPoly(){
    showAllPolys();
    printf("��ѡ�����ʽ(1-%d): ",polyManager.count);
    int choice;
    scanf("%d",&choice);
    getchar();
    if(choice < 0||choice>=polyManager.count){
        printf("��Чѡ��\n");
        return -1;
    }
    return choice-1;
} 


//�ú������ڶ��û�����Ķ���ʽ���з���,���ó�����count,ϵ��coef,ָ��exp������ 
int analysis(char*input, PolyNode terms[]){
    int count=0;
    char*token=strtok(input," ");
    
   while(token!=NULL)
   {
        float coef=1.0;
        int exp=0;
        char *ptr=token;
        int sign=1;

        if(*ptr=='+')
			ptr++;
        else if(*ptr=='-')
		{
            sign=-1;
            ptr++;
        }

        if(isdigit(*ptr)||*ptr=='.')
		{
            coef=atof(ptr);
        }
        coef*=sign;
        
        while(isdigit(*ptr)||*ptr=='.')
		{
            ptr++;
        }
        ////////////////////////
        if(*ptr=='x')
		{
            ptr++;
            if(*ptr=='^')
			{
                ptr++;
                exp=atoi(ptr);
            } 
			else 
			{
                exp=1;
            }
        } 
		else exp=0; 
		/////////////////////
		terms[count].coef=coef;
        terms[count].exp=exp;
        count++;
        //QAQ---------ciallo!
        token=strtok(NULL," ");
    }
    
    return count;
}

//�ú������ڴ���������ͷ�ڵ� 
Polylist createPoly() 
{
    Polylist poly = (Polylist)malloc(sizeof(PolyNode));
    if (!poly) {
        printf("�ڴ����ʧ��!\n");
        return NULL;
    }
    poly->next = NULL;
	return poly;
}

//���û�����������������ʽ
Polylist createPolyfrominput()
{
	Polylist h=createPoly();
	Polylist p;
	printf("���������ʽ(�����ÿո�ָ�����:6x^2 -3x +1\n");
	char input[100];
	PolyNode terms[100];
	fgets(input,100,stdin);
	int count=analysis(input,terms);
	int i=0;
	for(i=0;i<count;i++)
	{
		insertNode(h,terms[i].coef,terms[i].exp);
	}
	printfpoly(h);
	return h;
}


//������Ķ���ʽ��ӡ���� 
void printfpoly(Polylist poly)
{
	Polylist p= poly->next;
	int i=0;
	
	while(p!=NULL)
	{
		if(p->exp>=0)
		{
			if(i==0)
				printf("%.2fx^%d",p->coef,p->exp);
			else if(p->coef>0)
				printf("+%.2fx^%d",p->coef,p->exp);
			else if(p->coef<0) 
				printf("%.2fx^%d",p->coef,p->exp);
		}
		p=p->next;
		i++;
	}
	
	printf("\n");
}

//ָ���Ƚ� 
int compareExp(int a,int b)
{
	if(a==b) return 0;
	if(a>b) return 1;
	if(a<b) return -1;
}

//����ʽ�ӷ�
Polylist Ployadd(Polylist poly_a,Polylist poly_b)
{
    Polylist result=createPoly();
    Polylist pa,pb,pr;  
    pa=poly_a->next;
    pb=poly_b->next;
    while(pa!=NULL&&pb!=NULL)
    {
        switch(compareExp(pa->exp,pb->exp))
        {
            case 0:
                if(pa->coef+pb->coef!=0){
                	insertNode(result,pa->coef+pb->coef,pa->exp);
                    pa=pa->next;
                    pb=pb->next;
                    break;
                }
                else{
                    pa=pa->next;
                    pb=pb->next;
                    break;
                }
            case 1:
                {
                	insertNode(result,pa->coef,pa->exp);
                    pa=pa->next;
                    break;
                }
            case -1:
                {
                	insertNode(result,pb->coef,pb->exp);
                    pb=pb->next;
                    break;
                }
        }
    }
    
    while(pa != NULL) {
    	insertNode(result,pa->coef,pa->exp);
        pa=pa->next;
    }
    
    while(pb != NULL) {
		insertNode(result,pb->coef,pb->exp);
        pb=pb->next;
    }
    
    return result;
}

//����ʽ����
Polylist Ployminus(Polylist poly_a,Polylist poly_b)
{
    Polylist result=createPoly();
    Polylist pa,pb,pr;  
    pa=poly_a->next;
    pb=poly_b->next;
    while(pa!=NULL&&pb!=NULL)
    {
        switch(compareExp(pa->exp,pb->exp))
        {
            case 0:
                if(pa->coef+pb->coef!=0){
                	insertNode(result,pa->coef-pb->coef,pa->exp);
                    pa=pa->next;
                    pb=pb->next;
                    break;
                }
                else{
                    pa=pa->next;
                    pb=pb->next;
                    break;
                }
            case 1:
                {
                	insertNode(result,pa->coef,pa->exp);
                    pa=pa->next;
                    break;
                }
            case -1:
                {
                	insertNode(result,pb->coef,pb->exp);
                    pb=pb->next;
                    break;
                }
        }
    }
    
    while(pa != NULL) {
    	insertNode(result,pa->coef,pa->exp);
        pa=pa->next;
    }
    
    while(pb != NULL) {
		insertNode(result,pb->coef,pb->exp);
        pb=pb->next;
    }
    
    return result;
}

//����ʽ�˷�
Polylist Polymulti(Polylist poly_a,Polylist poly_b)
{
	Polylist pa=poly_a->next;
    Polylist pb;
    Polylist result=createPoly(); 
     while(pa != NULL)
     {
     	pb=poly_b->next;
     	while(pb != NULL)
     	{
     		double coef=pa->coef*pb->coef;
            int exp=pa->exp+pb->exp;
     		insertNode(result,coef,exp);
			pb=pb->next;	
		 }
		pa=pa->next;
	 }
	 return result;
} 

//����ʽɾ�� 
void Deletepoly(Polylist poly)
{
	Polylist p=poly;
	while(p)
	{
		Polylist m=p;
		p=p->next;
		free(m);	
	} 
}

//������� 
void insertNode(Polylist poly,double coef,int exp) {
    Polylist newNode=(Polylist)malloc(sizeof(PolyNode));
    newNode->coef=coef;
    newNode->exp=exp;
    newNode->next=NULL;
    
    if(poly->next==NULL||exp>poly->next->exp)
	{
        newNode->next=poly->next;
        poly->next=newNode;
        return;
    }
    
    Polylist current=poly->next;
    Polylist pre=poly;
    while(current != NULL&&current->exp>exp)
	{
        pre=current;
        current=current->next;
    }
    if (current!=NULL&&current->exp==exp){
        current->coef+=coef;
        free(newNode);
        if (current->coef == 0) {
            pre->next = current->next;
            free(current);
        }
    }else{
        newNode->next=current;
        pre->next=newNode;
    }
}


void display_menu() {
    int choice,i;
    
    while(1) {
        system("cls");  
        printf("========== ��̬����ʽ������ ==========\n");
        printf("1. ����/�༭����ʽ\n");
        printf("2. ����ʽ�ӷ�\n");
        printf("3. ����ʽ����\n");
        printf("4. ����ʽ�˷�\n");
        printf("5. �鿴���ж���ʽ\n");
        printf("6. ɾ������ʽ\n");
        printf("0. �˳�\n");
        printf("======================================\n");
        printf("��ѡ��: ");
        scanf("%d", &choice);
        
        switch(choice) {
            case 1: {
                int index = selectPoly();
                if(index >= 0) {
                    if(polyManager.polys[index] != NULL) {
                        Deletepoly(polyManager.polys[index]);
                    }
                    polyManager.polys[index] = createPolyfrominput();
                }
                break;
            }
                
            case 2: {
                printf("ѡ����������ʽ���мӷ�����:\n");
                int index1 = selectPoly();
                if(index1 < 0) break;
                int index2 = selectPoly();
                if(index2 < 0) break;
                
                Polylist result = Ployadd(polyManager.polys[index1], polyManager.polys[index2]);
                int resultIndex = addNewPoly(result);
                printf("�ӷ�����ѱ���Ϊ %s\n", getPolyName(resultIndex));
                printf("���: ");
                printfpoly(result);
                break;
            }
                
            case 3: {
                printf("ѡ����������ʽ���м�������:\n");
                int index1 = selectPoly();
                if(index1 < 0) break;
                int index2 = selectPoly();
                if(index2 < 0) break;
                
                Polylist result = Ployminus(polyManager.polys[index1], polyManager.polys[index2]);
                int resultIndex = addNewPoly(result);
                printf("��������ѱ���Ϊ %s\n", getPolyName(resultIndex));
                printf("���: ");
                printfpoly(result);
                break;
            }
                
            case 4: {
                printf("ѡ����������ʽ���г˷�����:\n");
                int index1 = selectPoly();
                if(index1 < 0) break;
                int index2 = selectPoly();
                if(index2 < 0) break;
                
                Polylist result = Polymulti(polyManager.polys[index1], polyManager.polys[index2]);
                int resultIndex = addNewPoly(result);
                printf("�˷�����ѱ���Ϊ %s\n", getPolyName(resultIndex));
                printf("���: ");
                printfpoly(result);
                break;
            }
                
            case 5:
                showAllPolys();
                break;
                
            case 6: {
                int index = selectPoly();
                if(index >= 0 && index < polyManager.count) {
                    if(polyManager.polys[index] != NULL) {
                        Deletepoly(polyManager.polys[index]);
                        polyManager.polys[index] = createPoly();
                        printf("%s �ѱ����\n", getPolyName(index));
                    }
                }
                break;
            }
                
            case 0: 
                for(i = 0; i < polyManager.count; i++) {
                    if(polyManager.polys[i] != NULL) {
                        Deletepoly(polyManager.polys[i]);
                    }
                }
                free(polyManager.polys);
                printf("�ټ���\n");
                return;
                
            default:
                printf("��Чѡ�����������룡\n");
        }
        
        printf("�����������...");
        getchar(); 
        getchar();
    }
}







